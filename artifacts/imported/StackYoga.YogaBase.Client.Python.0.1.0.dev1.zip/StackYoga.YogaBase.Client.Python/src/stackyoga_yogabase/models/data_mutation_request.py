from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .data_filter import DataFilter
    from .data_mutation_request_values import DataMutationRequest_values

@dataclass
class DataMutationRequest(Parsable):
    # The filters property
    filters: Optional[list[DataFilter]] = None
    # The returningColumns property
    returning_columns: Optional[list[str]] = None
    # The values property
    values: Optional[DataMutationRequest_values] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> DataMutationRequest:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: DataMutationRequest
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return DataMutationRequest()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .data_filter import DataFilter
        from .data_mutation_request_values import DataMutationRequest_values

        from .data_filter import DataFilter
        from .data_mutation_request_values import DataMutationRequest_values

        fields: dict[str, Callable[[Any], None]] = {
            "filters": lambda n : setattr(self, 'filters', n.get_collection_of_object_values(DataFilter)),
            "returningColumns": lambda n : setattr(self, 'returning_columns', n.get_collection_of_primitive_values(str)),
            "values": lambda n : setattr(self, 'values', n.get_object_value(DataMutationRequest_values)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_object_values("filters", self.filters)
        writer.write_collection_of_primitive_values("returningColumns", self.returning_columns)
        writer.write_object_value("values", self.values)
    

