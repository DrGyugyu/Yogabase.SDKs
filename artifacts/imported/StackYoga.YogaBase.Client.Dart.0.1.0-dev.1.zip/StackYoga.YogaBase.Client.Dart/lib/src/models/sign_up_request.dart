// ignore_for_file: type=lint
import 'package:microsoft_kiota_abstractions/microsoft_kiota_abstractions.dart';

/// auto generated
class SignUpRequest implements Parsable {
    ///  The email property
    String? email;
    ///  The invitationToken property
    String? invitationToken;
    ///  The password property
    String? password;
    /// Creates a new instance of the appropriate class based on discriminator value
    ///  [parseNode] The parse node to use to read the discriminator value and create the object
    static SignUpRequest createFromDiscriminatorValue(ParseNode parseNode) {
        return SignUpRequest();
    }
    /// The deserialization information for the current model
    @override
    Map<String, void Function(ParseNode)> getFieldDeserializers() {
        var deserializerMap = <String, void Function(ParseNode)>{};
        deserializerMap['email'] = (node) => email = node.getStringValue();
        deserializerMap['invitationToken'] = (node) => invitationToken = node.getStringValue();
        deserializerMap['password'] = (node) => password = node.getStringValue();
        return deserializerMap;
    }
    /// Serializes information the current object
    ///  [writer] Serialization writer to use to serialize this model
    @override
    void serialize(SerializationWriter writer) {
        writer.writeStringValue('email', email);
        writer.writeStringValue('invitationToken', invitationToken);
        writer.writeStringValue('password', password);
    }
}
